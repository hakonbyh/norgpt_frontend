import { HStack, Heading, Switch } from "@chakra-ui/react";
import { useContext } from "react";
import { ParamsContext } from "../context/ParamsContext";

interface ToggleProps {
  title: string;
  parameterKey: keyof Parameters;
}

interface Parameters {
  [key: string]: any;
}

function Toggle({ title, parameterKey }: ToggleProps) {
  const { currentParameters, setCurrentParameters } = useContext(ParamsContext);

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const valueAsBoolean = event.target.checked;
    setCurrentParameters({
      ...currentParameters,
      [parameterKey]: valueAsBoolean,
    });
  };
  return (
    <HStack>
      <Heading size="sm">{title}</Heading>
      <Switch
        size="lg"
        colorScheme="blue"
        isChecked={currentParameters[parameterKey]}
        onChange={handleChange}
      />
    </HStack>
  );
}

export default Toggle;
