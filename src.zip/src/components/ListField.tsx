import React, { ChangeEvent, KeyboardEvent, useState, useContext } from "react";
import {
  Box,
  Tag,
  TagLabel,
  TagCloseButton,
  Input,
  Flex,
  Heading,
} from "@chakra-ui/react";
import { ParamsContext } from "../context/ParamsContext";

interface ListFieldProps {
  title: string;
  parameterKey: string;
}

const ListField: React.FC<ListFieldProps> = ({ title, parameterKey }) => {
  const { currentParameters, setCurrentParameters } = useContext(ParamsContext);
  const [value, setValue] = useState<string>("");
  const [isFocused, setIsFocused] = useState<boolean>(false);

  const handleKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Enter") {
      event.preventDefault();
      addNumber();
    }
  };

  const addNumber = () => {
    const num = parseInt(value, 10);
    if (!isNaN(num)) {
      if (!currentParameters[parameterKey].includes(num)) {
        setCurrentParameters({
          ...currentParameters,
          [parameterKey]: [...currentParameters[parameterKey], num],
        });
        setValue("");
      } else {
        console.warn(`ID already exists: ${num}`);
      }
    } else {
      console.warn(`Invalid integer: ${value}`);
    }
  };

  const handleChange = (event: ChangeEvent<HTMLInputElement>) => {
    setValue(event.target.value);
  };

  const handleRemove = (num: number) => {
    setCurrentParameters({
      ...currentParameters,
      [parameterKey]: currentParameters[parameterKey].filter(
        (param: number) => param !== num
      ),
    });
  };
  return (
    <Box mb={0}>
      <Heading size="sm" my="4">
        {title}
      </Heading>
      <Flex
        mb={0}
        width={"300px"}
        maxH={"100px"}
        overflow={"scroll"}
        direction="row"
        wrap="wrap" // Here's the new prop
        border="1px solid"
        borderColor={isFocused ? "#3182CE" : "#E3E8EF"}
        borderRadius="md"
        alignItems="center"
        p="0"
        boxShadow={isFocused ? "0 0 0 1px #3182CE" : "none"}
        transition="all 0.3s ease"
      >
        {currentParameters[parameterKey].map((num: number, index: number) => (
          <Tag
            size="sm"
            key={index}
            borderRadius="full"
            variant="solid"
            colorScheme="green"
            mx={1}
            my={2}
          >
            <TagLabel>{num}</TagLabel>
            <TagCloseButton onClick={() => handleRemove(num)} />
          </Tag>
        ))}
        <Input
          type="text"
          value={value}
          onChange={handleChange}
          onKeyDown={handleKeyDown}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          placeholder={
            currentParameters[parameterKey].length === 0
              ? "Legg til et nummer og klikk Enter"
              : ""
          }
          flex={1}
          border="none"
          variant="none"
        />
      </Flex>
    </Box>
  );
};

export default ListField;
