export type MessageType = {
  from: "user" | "computer";
  text: string;
  prompt?: string;
  error?: boolean;
};

export type ModelItem = {
  name?: string;
  description?: string;
  region: string;
};

export type ModelItems = {
  [key: string]: ModelItem;
};

export type Mode = {
  mode: string;
};

export type Parameters = {
  [key: string]: any;
};
