import { Parameters } from "../types";

export function processResponse(
  selectedModel: string,
  selectedMode: string,
  answer: string
) {
  if (selectedModel.includes("instruct") && selectedMode === "generate") {
    const separatorIndex = answer.indexOf(": ");
    if (separatorIndex !== -1) {
      answer = answer.substring(separatorIndex + 2);
    }
  }

  if (selectedMode === "summarize") {
    const separatorIndex = answer.lastIndexOf("|||\\n");
    if (separatorIndex !== -1) {
      answer = answer.substring(separatorIndex + 5);
    }
  }

  return answer;
}

export function createPostParameters(
  parameters: Parameters,
  extraLength: number
) {
  const postParameters: Parameters = {};
  Object.entries(parameters).forEach(([key, value]) => {
    if (value !== null && !(Array.isArray(value) && value.length === 0)) {
      postParameters[key] = value;
    }
  });

  if ("max_length" in postParameters) {
    postParameters.max_length += extraLength;
  }

  return postParameters;
}
