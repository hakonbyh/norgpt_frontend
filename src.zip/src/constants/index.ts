import { Mode } from "../types";

export const API_BASE_URL =
  "https://sza5jdlx17.execute-api.eu-north-1.amazonaws.com/prod";

export const Modes: Mode[] = [{ mode: "generate" }, { mode: "summarize" }];
